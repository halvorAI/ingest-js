TEST ENVIRONMENT. This pack was built in the HalvorAI sandbox from test data.
It is not evidence of real payments.

HalvorAI evidence pack

Pack id: pck_01DEMO00000000000000000000

This pack supports, and does not replace, the bank's own investigation and any
report the bank decides to file.

Offline verification
1. Verify manifest.jws against the pack key from the JWKS (or a pinned key file).
   JWKS: https://api.halvorai.com/v1/.well-known/pack-keys
2. Check each file's sha256 against manifest.json.
3. For each event in events.jsonl, recompute JCS sha256 and check the producer
   signature against the source public key in chain.json.
4. Recompute the hash chain between contiguous included events and check daily
   anchors' signatures.
5. Print a pass/fail report.

CLI: npx @halvorai/ingest verify-pack <pack.zip>
